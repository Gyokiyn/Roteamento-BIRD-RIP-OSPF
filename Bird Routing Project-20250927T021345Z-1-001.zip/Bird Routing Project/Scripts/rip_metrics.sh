#!/bin/bash
echo "=== BIRD RIP Metrics ==="
date

echo "BIRD Status:"
sudo birdc show status

echo ""
echo "RIP Protocol Status:"
sudo birdc show protocols all rip1

echo ""
echo "RIP Routes:"
sudo birdc show route protocol rip1

echo ""
echo "All Routes:"
sudo birdc show route

echo ""
echo "Routing table size:"
sudo birdc show route | wc -l

echo ""
echo "System routes:"
ip route show | grep -v "169.254"

echo ""
echo "Convergence test - ping end-to-end:"
if [ "$(hostname)" = "GA-R1" ]; then
    time ping -c 1 192.168.23.3
elif [ "$(hostname)" = "GA-R3" ]; then
    time ping -c 1 192.168.12.1
else
    time ping -c 1 192.168.12.1
fi
