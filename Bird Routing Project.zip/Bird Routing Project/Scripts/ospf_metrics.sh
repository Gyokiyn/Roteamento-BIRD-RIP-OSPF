#!/bin/bash
echo "=== BIRD OSPF Metrics ==="
date

echo "BIRD Status:"
sudo birdc show status

echo ""
echo "OSPF Protocol Status:"
sudo birdc show protocols all ospf1

echo ""
echo "OSPF Neighbors:"
sudo birdc show ospf neighbors

echo ""
echo "OSPF State:"
sudo birdc show ospf state

echo ""
echo "OSPF Routes:"
sudo birdc show route protocol ospf1

echo ""
echo "All Routes:"
sudo birdc show route

echo ""
echo "Convergence test - ping end-to-end:"
if [ "$(hostname)" = "GA-R1" ]; then
    time ping -c 1 192.168.23.3
elif [ "$(hostname)" = "GA-R3" ]; then
    time ping -c 1 192.168.12.1
else
    time ping -c 1 192.168.12.1
fi
